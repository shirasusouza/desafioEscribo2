const Router = require("express").Router;
const rotas = Router();
const controller = require("../controller/controllerMain");

// rotas
rotas.get("/login", (req, res) => {
    const dados = req.body;
    const login = controller.entrar(dados);
    login.then((login) => res.status(200).json(login))
        .catch(error => res.status(400).json(error.message));
});

rotas.post("/cadastro", (req, res) => {
    const dados = req.body;
    const cadastro = controller.cadastro(dados);
    cadastro.then((cadastro) => res.status(200).json(cadastro))
        .catch(error => res.status(400).json(error.message));
    
});

rotas.put("/editar/:id", (req, res) => {
    const { id } = req.params;
    res.send("o usuario " + id + " foi alterado com sucesso");
});

rotas.delete("/deletar/:id", (req, res) => {
    const { id } = req.params;
    res.send("o usuario " + id + " deletado com sucesso");
});

module.exports = (rotas);