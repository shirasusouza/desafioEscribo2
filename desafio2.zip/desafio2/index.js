const express = require("express");
const app = express();
const port = 3000;
const conexao = require("./bancoInfra/database.js");
const tabelas = require("./bancoInfra/tabelas.js");
const router = require("./routes/index.js");

router(app, express);
tabelas.init(conexao);

app.listen(port, (error) => {
   if (error) {
      console.log("deu errado");
      return;
   }
   console.log("funfou");
});