class Tabelas {
    init(conexao) {
        this.conexao = conexao;
        this.criarTabelaUsuarios();
    }

    criarTabelaUsuarios() {
        const sql = 'CREATE TABLE usuarios( id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, email TEXT NOT NULL, senha TEXT NOT NULL, nome TEXT NOT NULL, criacao date NOT NULL, ultLogin date NOT NULL, ultAtt date NOT NULL, ddd INT , telefone INT)';
        this.conexao.query(sql, (error) => {
            if (error) {
                console.log("erro pra tabetla usuarios: " + error);
                return;
            }
        });
    }
}
module.exports = new Tabelas();