const conexao = require("../bancoInfra/database")
class model {

    login(dados) {
        const email = dados.email;
        const senha = dados.senha;
        const login = "SELECT id, criacao, ultAtt, ultLogin, telefone, ddd  FROM usuarios WHERE email = '" + email + "' AND senha = '" + senha + "'; ";
        return new Promise((resolve, reject) => {
            conexao.query(login, dados, (error, resposta) => {
                if (error) {
                    reject(error);
                }
                resolve(resposta);
            });
        });
    }

    cadastrar(dados) {
        const data = new Date();
        const cadastro = "INSERT INTO usuarios SET  email = '" + dados.email + "', senha = '" + dados.senha + "', nome = '" + dados.nomeUsuario + "', ddd = " + dados.ddd + ", telefone = " + dados.telefone + ", criacao = '" + data + "';"
        return new Promise((resolve, reject) => {
            conexao.query(cadastro, dados, (error, resposta) => {
                if (error) {
                    reject(error);
                }
                resolve(resposta);
            });
        });
    }

}
module.exports = new model();