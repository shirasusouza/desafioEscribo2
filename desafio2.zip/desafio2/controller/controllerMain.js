const modelMain = require("../models/modelMain");

class controllers {

    cadastro(dados) {
        return modelMain.cadastrar(dados);
    }

    entrar(dados) {
        return modelMain.login(dados);

    }

}
module.exports = new controllers();